module.exports = {
    /**
     * Current Design only supports single page application with no routing( Or routing can be customized as per app home 
     *  dir /portal/spa/:app/)
     */
    /**
 * Card Template
 * [ //row
 * { //item
 *      cardTitle: string, //title of the card
        cardWidth: number, //width of the card
        cardText:string, // Extra details about the app can be added here
        cardHeight: number, //height of the card
        cardSPAName: string, //your single page application name;
                             // Create a directory named as same you passed on cardSPAName variable
                             // inside spa folder ; create index.html for your app
                             // index.html will be the entrypoint to your app
        cardIconClass: string, //Set card main icon class
        badgeIcon: string, //Set card badge icon class
        cardTextClamp: int, //Set clamp line for card text
    }
 * ]
 */
    cardsMetaData: [
        [{
                cardTitle: 'Android Asset Studio',
                cardWidth: 300,
                cardText: "A collection of tools to easily generate assets such as launcher icons for your Android app.Check out it's github repository",
                cardHeight: 200,
                cardSPAName: 'androidassetstudio',
                cardIconClass: 'fa fa-android',
                badgeIcon: 'fa fa-pencil-square-o ',
                cardTextClamp: 3,
            }, {
                cardTitle: 'Monaco Text Compare',
                cardWidth: 300,
                cardText: "Monaco is the tool drive microsoft visula studio code editing. Check it's github page for more details",
                cardHeight: 200,
                cardSPAName: 'textcompare',
                cardIconClass: 'fa fa-android',
                badgeIcon: 'fa fa-pencil-square-o ',
                cardTextClamp: 3,
            },
            {
                cardTitle: 'Prettier',
                cardWidth: 300,
                cardText: "Monaco is the tool drive microsoft visula studio code editing. Check it's github page for more details",
                cardHeight: 200,
                cardSPAName: 'prettier',
                cardIconClass: 'fa fa-android',
                badgeIcon: 'fa fa-pencil-square-o ',
                cardTextClamp: 3,
            },

            {
                cardTitle: 'Converter',
                cardWidth: 200,
                cardHeight: 150,
                cardSPAName: 'converter',
                cardIconClass: 'fa fa-calculator',
                badgeIcon: 'fa fa-firefox',
                cardTextClamp: 0,
            },
        ],
    ],

}