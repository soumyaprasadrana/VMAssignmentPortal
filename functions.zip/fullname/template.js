module.exports = {
  template: (context, grid, row, utils) => {
    if (typeof row != "undefined" && row != null) {
      console.log("<TEMPLATE SCRIPT> <<ROW>> ", row);
      return row.FIRSTNAME + " " + row.MIDDLENAME + " " + row.LASTNAME;
    }
    //You can use context or grid or row to build the html dynamically
    domContent = `
    <style>
    .table-fixed{
        table-layout: fixed;
        word-wrap: break-word;
        display: table;
    }
    .table-sm tr td {
        text-align:center !important;
    }
    .table thead th {
        border: 1px solid #dee2e6 !important;
    }
    .table tbody tr,.table tbody td{
        border: 1px solid #dee2e6 !important;
    }
    </style>
<div id="matB"></div>  
<div class="container-fluid-lg p-3 my-3">
    <div id="abc" class="row">
        <div class="col-xs-6 ">
            <h3 class="page-title ml-3">
                 Full Name Example
                <hr>
            </h3>
        </div>
    </div>
    <div class="row p-3">
    <button class="btn btn-portal mb-2" id="openDialog">Open Dialog </button>
    <table id="data_table" class="table table-responsive table-sm">
               <thead>
                  <tr>
                     <th ><center>First Name</center></th>
                     <th ><center>Middle Name</center></th>
                     <th ><center>Last Name</center></th>
		     <th ><center>Full Name</center></th>
                     <th > Actions </th>
                  </tr>
                 
               </thead>
               <tbody>`;
    if (grid.length == 0) {
      domContent += `<tr ><td colspan="5"> There is nothing to show ... </td></tr>`;
    }
    for (var item of grid) {
      domContent += `
                    <tr>
                        <td>${item.FIRSTNAME}</td>
                        <td>${item.MIDDLENAME}</td>
			<td>${item.LASTNAME}</td>
                        <td>${item.FIRSTNAME +
                          " " +
                          item.MIDDLENAME +
                          " " +
                          item.LASTNAME}</td>
                        <td><center> <span id="alertName">  <i  meta='${JSON.stringify(
                          item
                        )}' class="fa fa-envelope-open-o btn btn-primary"></i></span><center></td>
                    </tr>
                `;
    }
    domContent += `
               </tbody>
            </table></div>`;
    return domContent;
  },
};
