const { logger } = require("../../../config");

module.exports = {
  server: (app) => {
    function handleTESTAPI(req, res, app) {
      return res
        .status(200)
        .send(
          "Awsome! Custom API is listening for user defined function fullnameexample..."
        );
    }
    function handleTESTAPIPOST(req, res, app) {
      return res.status(200).json({
        text:
          "Awsome! Custom API is listening for user defined function fullnameexample...",
        body: req.body.params,
      });
    }
    app.get("/api/v1/testAPI", handleTESTAPI);
    app.post("/api/v1/testAPI", handleTESTAPIPOST);
  },
};
