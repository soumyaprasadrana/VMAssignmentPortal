module.exports = {
  client: (parent, grid, row, utils) => {
    console.log("<CLIENT SCRIPT> <<ROW>> ", row);
    return {
      //data members you want to us in template script
      utils: utils,
      eventBindings: {
        addRecordX: {
          type: "click",
          event: (context, event) => {
            console.log("======== ADD RECORD CLICKED ==========");
            context.utils.getNativeFunction("add")();
          },
        },
        openDialog: {
          type: "click",
          event: (context, event) => {
            const dialogService = context.utils.getApplicationService("dialog");
            dialogService.openInputDialog(
              {
                title: "Question 1",
                label: "What is your age ?",
                isText: true,
                titleIcon: true,
                iconClass: "",
              },
              (res) => {
                if (res.dataCtrl) {
                  dialogService.openInputDialog(
                    {
                      title: "Question 2",
                      label: "What is profession ?",
                      isText: true,
                      titleIcon: true,
                      iconClass: "",
                    },
                    (res2) => {
                      if (res2.dataCtrl) {
                        window.alert(
                          "Employee age is " +
                            res.dataCtrl +
                            " and is a " +
                            res2.dataCtrl +
                            " by profession."
                        );
                      }
                    }
                  );
                }
              }
            );
          },
        },
      },
      templateScript: (context, utils) => {
        $("#addRecord").on("click", () => {
          utils.getNativeFunction("add")();
        });
        $("#data_table tbody tr").find("#alertName").each(function() {
          $this = $(this);
          $this.on("click", (event) => {
            const targetRow = JSON.parse(event.target.attributes["meta"].value);
            window.alert(
              targetRow.FIRSTNAME +
                " " +
                targetRow.MIDDLENAME +
                " " +
                targetRow.LASTNAME
            );
          });
        });
      },
      templateScriptBefore: () => {},
    };
  },
};
